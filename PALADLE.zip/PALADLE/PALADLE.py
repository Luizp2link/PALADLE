from tkinter import *
import random


def main():
    #configura variaveis globais
    global palavra_em_lista
    palavra_em_lista = []

    num_tentativas = 0
    lista_tentativas = []
    global ganhou
    ganhou = False
    global tentativas
    tentativas = 0
    global linha
    linha = 1
    global chute_lista
    chute_lista = []
    global chute
    chute = ''
    global palavra
    palavra = ''



    #Configura janela_1
    global janela_1
    janela_1 = Tk()
    janela_1.title("PALADLE")
    janela_1.geometry("490x500")

    #Mensagem de entrada
    texto_TITULO = Label(janela_1, text= "\n BEM VINDO(A) AO PALADLE!!!", font=('Times 18 bold'))
    texto_TITULO.grid(columnspan=2, row=0)

    texto_inst = Label(janela_1, text="\n \n INSTRUÇÕES:", font=('Times 12'), justify= CENTER)
    texto_inst.grid(columnspan=2, row=2)

    texto_INSTRUCOES = Label(janela_1, 
                             text="     Para cada jogada, será gerada uma palavra de 5 letras no idoma escolhido, você terá 6\ntentativas para acerta-la. \n     O simbolo \"*\" diz que a palavra possui essa letra e está NA POSIÇÃO CORRETA, o \nsimbolo \"+\" diz que a palavra possui essa letra mas na POSIÇÃO ERRADA, enquanto \no \"_\" diz que a palavra não possui essa letra. BOA SORTE!!!!",
                             font=('Times 10'), justify=LEFT)
    texto_INSTRUCOES.grid(columnspan=2, row=3, padx=10, pady=10)


    #Escolhe linguagem
    texto_IDIOMA = Label(janela_1, text= "\n \n ESCOLHA SEU IDIOMA: \n ", font=('Times 14'))
    texto_IDIOMA.grid(columnspan=2, row= 5)
    palavra_em_lista = []

    botao_ing = Button(janela_1, text="Inglês", command=idioma_en, font=('Times 12'))
    botao_ing.grid(column=0, row= 9, padx=10, pady=10)

    botao_pt = Button(janela_1, text="Português", command=idioma_pt, font=('Times 12'))
    botao_pt.grid(column=1, row= 9, padx=10, pady=10)


    #fim da janela_1
    janela_1.mainloop()

#Apos escolher idioma, configura a janela_2 (parte do jogo)
def inicializar_pagina_jogo():
    encerrra_pag()
    global janela_2
    janela_2 = Tk()
    janela_2.title("PALADLE")
    janela_2.geometry("490x500")
    faz_tentativa()


#opçoes para a entrada do usuario
def faz_tentativa():
    '''É chamada pela função inicializar_pagina_jogo() e edita as entradas e botoes para o usuario escrever sua tentativa.
       Ela chama a função le_entry '''
    if not ganhou:
        global tentativas
        global chute_entry
        texto_escreva_chute = Label(janela_2, text="Digite uma palavra: ", font=("Times 14"))
        texto_escreva_chute.grid(column = 0, row=0, padx=10, pady=10)
        chute_entry = Entry(janela_2, width = 15, font=('Times 14'))
        chute_entry.grid(column = 1, row=0, padx=10, pady=10)
        botao_entry = Button(janela_2, text="TESTAR", command=le_entry, padx=15, pady=10, font=('Times 14'), bg='light green' )
        botao_entry.grid(column = 2, row=0, padx=20, pady=10)
        botao_aviso = Button(janela_2, text="Avisos (clique)", 
                            font='Times 10', bg='light blue', command=avisos)
        botao_aviso.grid(column=2, row=1)
        tentativas += 1

def avisos():
    global janela_aviso
    janela_aviso = Tk()
    janela_aviso.title("PALADLE")
    janela_aviso.geometry("230x270")
    mensagem_aviso = Label(janela_aviso, text="Atenção: \n \n1. A palavra precisa ter \n5 letras \n2. Não comece com letra \nmaiúscula \n3. Apesar de não dar \n problemas, evite usar \nacentos. ", 
                           font='Times 14')
    mensagem_aviso.grid(column=0, row=0, padx=15, pady=15)
    botao_sair = Button(janela_aviso, text="Entendido", width=10, command=fechar_aviso)
    botao_sair.grid(column=0, row=1, padx=10, pady=10)

def fechar_aviso():
    janela_aviso.destroy()




#Lê a class Entry 
def le_entry():
    '''Transforma a class entry da função faz_tentativa() em uma variavel (chute) e checa se é a palavra é válida (possui 5 letras).
       Se for válida, chama a função imprime_resultados(), caso contrario pede para o usuraio digitar novamente. '''
    global chute
    chute = chute_entry.get()
    if checa_chute(chute):
        imprime_resultados()
    else:
        faz_tentativa()


#Define o idioma do jogo para inglês e sorteia a palavra
def idioma_en():
    sorteia_word()
    texto_IDIOMA_result = Label(janela_1, text= "*** Você escolheu inglês. ***", font=('Times 12'))
    texto_IDIOMA_result.grid(columnspan=2, row= 11, padx=30, pady=15)
    botao_INICIAR = Button(janela_1, text=" INICIAR ", command=inicializar_pagina_jogo, font=('Times 14'), bg='light green')
    botao_INICIAR.grid(columnspan=2, row=12, padx=10, pady=10)
    

#Define o idioma do jogo para português, cria o botão iniciar e sorteia a palavra
def idioma_pt():
    sorteia_palavra()
    texto_IDIOMA_result = Label(janela_1, text= "*** Você escolheu português. ***", font=('Times 12'))
    texto_IDIOMA_result.grid(columnspan=2, row= 11, padx=30, pady=15)
    botao_INICIAR = Button(janela_1, text=" INICIAR ", command=inicializar_pagina_jogo, font=('Times 14'), bg='light green')
    botao_INICIAR.grid(columnspan=2, row=12)




# sorteia uma palavra da lista em pt (e coloca na variavel global)
def sorteia_palavra():
    global palavra_em_lista
    global palavra
    lista_palavras = cria_lista_palavras("palavras.txt")
    palavra = lista_palavras[random.randint(0,len(lista_palavras)-1)]
    palavra_em_lista = transforma_chute(palavra)


# sorteia uma palavra da lista em ing (e coloca na variavel global) 
def sorteia_word():
    global palavra_em_lista
    global palavra
    lista_palavras = cria_lista_palavras("words.txt")
    palavra = lista_palavras[random.randint(0,len(lista_palavras)-1)]
    palavra_em_lista = transforma_chute(palavra)

    


def da_feedback(palavra, chute):
    ''' Recebe a `palavra` secreta e o `chute` do usuario e devolve
     uma lista ‘feedback’ de 5 elementos para indicar acertos e erros. 
     A lista `feedback` deve conter o 
     valor 1 (verde) se a letra correspondente em `chute` ocorre na mesma posicao
     em `palavra` (letra certa no lugar certo), deve conter 2 se a letra 
     em `chute` ocorre em outra posicao em `palavra` (letra certa no lugar errado),
     e deve conter 0 caso contrario. '''
    feedback_numeros = []
    chute = transforma_chute(chute)
    for i in range(len(chute)):
        check = False
        if chute[i]== palavra[i]:
            feedback_numeros.append(1)
        else:
            for letra in palavra:
                if letra == chute[i] and not check:
                    feedback_numeros.append(2)
                    check = True
            if not check:
                feedback_numeros.append(0)
    return feedback_numeros

#imprime na tela as tentativas do usuario
def imprime_resultados():
    '''Essa funçaõ realiza as seguintes operações:
       1. Atravez dos numero na lista feedback_numeros, checa se o usuario acertou a palavra (todos os numeros devem ser 1) e fez menos de 6 tentativas.
       2. Se o jogador não acertou, a funçao imprime a ultima tentativa do jogador e chama a função faz_tentativa() para o
        usuario jogar novamente.
       3. Se passou as 6 tentativas e o usuario nao acertou, imprime a mensagem de derrota e habilita a opcao de recomeçar.
       4. Se o jogador acertou, imprime a mensagem de vitória e habilita a opção de recomeçar.'''
    global linha
    global chute
    global ganhou
    global palavra
    chute_temp = chute
    temp_feedback = da_feedback(palavra_em_lista, chute)
    temp_fdb_soma = 0
    for numero in temp_feedback: #possivel mudança: indicador de passagem
        if numero == 1:
            temp_fdb_soma += 1
    if not ganhou and tentativas <=6: 
        chute_lista = chute_em_lista(chute_temp)
        feedback = interpreta_feedback(da_feedback(palavra_em_lista, chute_lista))
        tentativa = Label(janela_2, text= chute_lista, font=("Times 14"), bg="light grey")
        tentativa.grid(column=0, row=linha, padx=10)
        feedback_imprime = Label(janela_2, text=feedback, font=("Times 14"), bg="light grey" )
        feedback_imprime.grid(column=1, row=linha, padx=10)
        linha += 1
        if temp_fdb_soma == 5:
            resultado = Label(janela_2, text="PARABÉNS!!!", font=('Times 14'))
            resultado.grid(columnspan=3, row=linha)
            ganhou = True
            botao_restart = Button(janela_2, text="RECOMEÇAR", command=restart, font='Times 14 bold')
            botao_restart.grid(columnspan=3, row=linha+1, padx=10, pady=10)
        else:
            faz_tentativa()
    else:
        resultado = Label(janela_2, text="\n \n Que pena... Você perdeu. \nA palavra era {}".format(palavra), font=('Times 14'))
        resultado.grid(columnspan=3, row=linha)
        botao_restart = Button(janela_2, text="RECOMEÇAR", command=restart, font='Times 14 bold')
        botao_restart.grid(columnspan=3, row=linha+1, padx=10, pady=10)

#transforma o chute(str) em uma lista
def chute_em_lista(chute):
    chute = transforma_chute(chute)
    lista_chute =[]
    for letra in chute:
        lista_chute.append(letra)
    return lista_chute

#Transforma os numeros da lista de feedback em simbolos representativos
def interpreta_feedback(feedback_nume):
    feedback = []
    for numero in feedback_nume:
        if numero == 1:
            feedback.append("*")
        elif numero == 2:
            feedback.append("+")
        else:
            feedback.append("_")
    return feedback

#checa se o chute não tem 5 letras
def checa_chute(tentativa):
    '''chega se o chute não possui nenhuma letra ou tamanho inválido.
    Letra invalida = ja utilizada e não esta na palavra'''
    if len(tentativa) != 5:
        return False
    return True




    
#retira os acentos das palavras (primeiramente usado para os chutes, por isso o nome)
def transforma_chute(chute):
            '''>>>sem usar outra biblioteca<<<, retira os acentos de vogais e ç'''
            a = ["à", "á", 'â', "ã"]
            e = ["é", "è", "ê"]
            i = ["ì", "í", "î"]
            o = ["ò", "ó", "ô"]
            u = ["ù", "ú", "û"]
            c = ["ç"]
            chute_teste= []
            chute_sem_acento = []
            for letra in chute:
                chute_teste.append(letra)
            
            for letra in chute_teste:
                tem_acento = False
                for vogal in a:
                    if letra == vogal:
                        chute_sem_acento.append("a")
                        tem_acento = True
                for vogal in e:
                    if letra == vogal:
                        chute_sem_acento.append("e")
                        tem_acento = True
                for vogal in i:
                    if letra == vogal:
                        chute_sem_acento.append("i")
                        tem_acento = True
                for vogal in o:
                    if letra == vogal:
                        chute_sem_acento.append("o")
                        tem_acento = True
                for vogal in u:
                    if letra == vogal:
                        chute_sem_acento.append("u")
                        tem_acento = True
                for vogal in c:
                    if letra == vogal:
                        chute_sem_acento.append("c")
                        tem_acento = True
                if not tem_acento and letra != "\n":
                    chute_sem_acento.append(letra)
            return chute_sem_acento

def cria_lista_palavras(nome_arquivo):
        ''' recebe uma string com o nome do arquivo e devolve uma lista
            contendo as palavras do arquivo'''
        arq = open(nome_arquivo, "r")
        lista_palavras = []
        for palavra in arq:
            lista_palavras.append(palavra)
        return lista_palavras

def encerrra_pag(): 
    janela_1.destroy()

def restart():
    janela_2.destroy()
    main()


if __name__ == "__main__":
    main()